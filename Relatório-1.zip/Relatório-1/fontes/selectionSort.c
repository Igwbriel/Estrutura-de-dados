#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void selectionSort(int arr[], int n) {
    for (int i = 0; i < n - 1; i++) {
        int min_idx = i;
        for (int j = i + 1; j < n; j++) {
            if (arr[j] < arr[min_idx]) {
                min_idx = j;
            }
        }
        if (min_idx != i) {
            int temp = arr[i];
            arr[i] = arr[min_idx];
            arr[min_idx] = temp;
        }
    }
}

int main() {
    int tamanho_max = 10000;

    FILE* arquivo = fopen("averageSelection.txt", "w");
    if (arquivo == NULL) {
        printf("Erro ao abrir o arquivo de dados.\n");
        return 1;
    }

    // Executar o algoritmo Selection Sort para diferentes tamanhos de vetor
    for (int tamanho = 10; tamanho <= tamanho_max; tamanho += 10) {
        // Criar o vetor de tamanho atual
        int* v = (int*)malloc(tamanho * sizeof(int));

        // Preencher o vetor com valores aleatórios
        srand(time(NULL));
        for (int i = 0; i < tamanho; i++) {
            v[i] = rand() % 1000;
        }

        clock_t inicio = clock();

        // Ordenar o vetor usando o algoritmo Selection Sort
        selectionSort(v, tamanho);

        clock_t fim = clock();

        // Calcular o tempo de execução em segundos
        double tempo_execucao = (double)(fim - inicio) / CLOCKS_PER_SEC;

        // Escrever o tamanho do vetor e o tempo de execução no arquivo de dados
        fprintf(arquivo, "%d %lf\n", tamanho, tempo_execucao);

        // Liberar a memória alocada para o vetor
        free(v);
    }

    // Fechar o arquivo de dados
    fclose(arquivo);

    // Chamar o Gnuplot para gerar o gráfico
    FILE* gnuplot = popen("gnuplot -persistent", "w");
    if (gnuplot != NULL) {
        // Configurar o estilo do gráfico
        fprintf(gnuplot, "set style line 1\n");
        fprintf(gnuplot, "set xlabel 'Tamanho do Vetor'\n");
        fprintf(gnuplot, "set ylabel 'Tempo de Execução (segundos)'\n");
        fprintf(gnuplot, "plot 'averageSelection.txt' with linespoints\n");

        // Fechar o processo do Gnuplot
        pclose(gnuplot);
    } else {
        printf("O Gnuplot não está instalado ou ocorreu um erro ao chamá-lo.\n");
        return 1; 
    }

    return 0;
}
