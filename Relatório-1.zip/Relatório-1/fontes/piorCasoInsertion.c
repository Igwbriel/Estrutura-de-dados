#include <stdio.h>
#include <unistd.h>
#include <sys/time.h>
#include <stdlib.h>

void insertion_sort(int *v, unsigned int n)
{
    int i, j, k;
    for (i = 1; i < n; i++)
    {
        k = v[i];
        j = i - 1;

        while (j > 0 && v[j] > k)
        {
            v[j + 1] = v[j];
            j = j - 1;
        }

        v[j + 1] = k;
    }
}

int main() {
  int n, *v;
  int i;
  struct timeval b, a;
  long long unsigned int ub, ua;
  

  for(n = 100; n <= 10000; n = n + 10){
    v = (int *) malloc(n * sizeof(int));
    for(i = 0; i < n; i++)
      v[i] = n - i;
    
    gettimeofday(&b, NULL);
    insertion_sort(v,n);
    gettimeofday(&a, NULL);

    free(v);

    ub = 1000000 * b.tv_sec + b.tv_usec;
    ua = 1000000 * a.tv_sec + a.tv_usec;

    printf("%d %lld\n", n, ua - ub);
  }
  return 0;
}